package com.study.andriod.project6.즐겨찾기;

public class Fr1_Item {

    private String stNum;
    private String stName;


    public Fr1_Item(String stName, String stNum){
        this.stName = stName;
        this.stNum = stNum;
    }

    public String getStNum() {
        return stNum;
    }

    public void setStNum(String stNum) {
        this.stNum = stNum;
    }

    public String getStName() {
        return stName;
    }

    public void setStName(String stName) {
        this.stName = stName;
    }

}
