package com.study.andriod.project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "lecture";

    EditText edit;
    TextView textView;

    String key = "zwuo5Q4WhY1qySU06kW8PI1YyuxlbJvGCW0IA9gD9owovUg91hVXUnmbGt6Mu%2FM4Q8V%2F7o8PEWa3Dz1%2B2vPhTw%3D%3D";

    busTask data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.INTERNET},1);
        }
    }

    public void onBtn(View v) {
        data = new busTask();
        data.execute();
        //edit.setText("");
    }

    private class busTask extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String...params){

            try{
                return (String)downloadUrl();

            }  catch (Exception e) {
                return "실패";
            }
        }

        @Override
        protected void onPostExecute(String result){
            Log.d(TAG,"qwqwqw :"+result);
            StringBuffer buffer = new StringBuffer();
            try {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();

                xpp.setInput(new StringReader(result));
                int eventType = xpp.getEventType();
                String tag = "";

                while (eventType != XmlPullParser.END_DOCUMENT){
                    switch (eventType){
                        case XmlPullParser.START_DOCUMENT:
                            buffer.append("파싱 시작...\n");
                            break;

                        case XmlPullParser.START_TAG:
                            tag = xpp.getName();

                            if(tag.equals("busArrivalList"));
                            else if(tag.equals("locationNo1")){
                                buffer.append("첫번째 위치 : ");
                                xpp.next();
                                buffer.append(xpp.getText());
                                buffer.append("\n");
                                Log.d(TAG, "bbb:"+xpp);
                            }
                            else if(tag.equals("locationNo2")){
                                buffer.append("두번째 위치 : ");
                                xpp.next();
                                buffer.append(xpp.getText());
                                buffer.append("\n");
                                Log.d(TAG, "bbb:"+xpp);
                            }
                            break;
                        case XmlPullParser.TEXT:
                            break;
                        case XmlPullParser.END_TAG:
                            tag = xpp.getName();

                            if(tag.equals("busArrivalList")) buffer.append("\n");
                            break;
                    }
                    eventType = xpp.next();
                }
                textView.setText(buffer.toString());
            }catch (Exception e){
                e.printStackTrace();
                Log.d(TAG,"qwweqwe:에러"+e);
            }
        }
    }

    private String downloadUrl() throws IOException{
        HttpURLConnection con = null;
        String str = "200000078";
        String location = URLEncoder.encode(str);
        String line = null;
        String page = "";

        String query = "http://openapi.gbis.go.kr/ws/rest/busarrivalservice/station?\n" +
                "serviceKey="+key+"&stationId="+location+"";
        try{
            URL url = new URL(query);
            con = (HttpURLConnection) url.openConnection();

            BufferedInputStream buf = new BufferedInputStream(con.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(buf,"utf-8"));
            while ((line = bufferedReader.readLine()) != null){
                page += line;
            }
            return page;
        }finally {
            con.disconnect();
        }

    }
}
